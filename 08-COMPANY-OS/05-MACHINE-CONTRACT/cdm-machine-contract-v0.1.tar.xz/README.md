# CDM Machine Contract Package v0.1

This package is the executable contract layer for the Company Discovery Manifest (CDM) and Company Filesystem Hierarchy Standard (CFHS).

It is intended to be consumed by:
- discovery installers,
- connector implementations,
- policy engines,
- schema validators,
- mapping engines,
- certification runners,
- Company Kernel bootstrap tooling.

## Contract layers

1. **JSON Schema** — structural validity of CDM objects and manifests.
2. **Connector Interface** — safe, read-only-by-default discovery contract.
3. **Inference Rule Format** — machine-readable candidate inference with confidence, authority, risk, and confirmation gates.
4. **Mapping Rule DSL** — deterministic conversion from normalized CDM objects to CFHS paths.
5. **Operational Validation Rules** — safety/completeness rules beyond JSON shape.
6. **Certification Profile** — CDM-0 through CDM-5 gates.
7. **Certification Test Suite** — positive and negative fixtures.
8. **Sample Manifest** — implementation-ready example.

## Directory layout

```text
cdm-machine-contract-v0.1/
├── README.md
├── package.manifest.json
├── requirements.txt
├── schemas/
│   ├── cdm.schema.json
│   ├── envelope.schema.json
│   ├── evidence.schema.json
│   └── ... one schema per CDM object type
├── specs/
│   ├── connector-interface.yaml
│   ├── connector-scan-profiles.yaml
│   ├── discovery-question-catalog.yaml
│   ├── artifact-request-catalog.yaml
│   ├── inference-rule.schema.json
│   ├── mapping-rule.schema.json
│   ├── mapping-rule-dsl.md
│   ├── validation-rule.schema.json
│   ├── validation-rules.yaml
│   ├── certification-test.schema.json
│   └── certification-profile.yaml
├── rules/
│   ├── inference-rules.yaml
│   └── mapping-rules.yaml
├── examples/
│   └── company.cdm.yaml
├── tests/
│   ├── certification-tests.yaml
│   └── fixtures/
└── scripts/
    └── validate_package.py
```

## JSON Schema version

All JSON Schemas use **JSON Schema Draft 2020-12**.

`schemas/cdm.schema.json` is the root manifest schema. Modular object schemas are separately addressable and are referenced by the root schema.

## CDM record envelope

Most normalized CDM records inherit the same logical metadata contract:

- `id`
- `kind`
- `status`
- `source`
- `provenance`
- `evidence`
- `confidence`
- `authority`
- `classification`
- `resolution`
- `mapping`
- `version`
- `checksum`
- `labels`

The envelope intentionally separates:
- **confidence**: how strongly the claim is supported;
- **authority**: how authoritative the evidence/source is;
- **resolution**: whether the company has accepted the claim as canonical.

High confidence does not grant authority.

## Safety rules

The package encodes these constitutional invariants:

- discovery is read-only by default;
- AI/inference cannot self-canonicalize consequential facts;
- no P0 unknown may remain for boot certification;
- technical permissions are distinct from business authority;
- consequential authority must be bounded;
- agent authority is non-delegable by default;
- raw secrets are not allowed in the manifest;
- privileged CFHS paths require confirmed A3+ sources;
- `/tmp` cannot contain canonical state;
- critical systems require ownership and recovery semantics;
- CDM-5 requires explicit autonomy evaluation evidence.

## Connector interface

`specs/connector-interface.yaml` defines:

- descriptor negotiation;
- authorization;
- schema discovery;
- scanning;
- checkpoints;
- optional subscriptions;
- health;
- revocation;
- error semantics.

A connector returns normalized discovery records and evidence; it does not directly mutate CFHS canonical state.

## Connector scan profiles

`specs/connector-scan-profiles.yaml` provides standard profiles for:

- identity provider
- email
- calendar
- file storage
- CRM
- accounting
- payment processor
- HR/payroll
- source control
- project management
- support
- website/CMS
- analytics
- advertising
- automation platforms
- databases
- data warehouses
- cloud infrastructure
- e-signature
- phone/SMS
- social platforms

Profiles default to metadata-first discovery and no mutation.

## Discovery questions

`specs/discovery-question-catalog.yaml` contains 141 machine-readable discovery questions.

The question engine should ask only unresolved questions needed to remove the highest-risk uncertainty.

Questions carry:
- module,
- priority,
- answer type,
- dependencies,
- required certification context,
- high-impact flag.

## Artifact requests

`specs/artifact-request-catalog.yaml` contains 55 standard artifact requests.

Artifacts are requested only when connector evidence and existing records cannot resolve a required fact.

## Inference engine

`rules/inference-rules.yaml` contains the v0.1 canonical IR-001 through IR-017 rule set.

Inference rules produce **candidates**, not truth.

Every inference records:
- inputs,
- predicates,
- produced object,
- base confidence,
- confidence adjustments,
- confirmation conditions,
- minimum authority,
- risk,
- provenance.

## Mapping DSL

`rules/mapping-rules.yaml` contains starter deterministic CFHS mappings.

The mapping engine:
1. orders by priority;
2. matches object kind;
3. evaluates predicates and guards;
4. renders deterministic target paths;
5. preserves provenance;
6. applies the mapping mode.

Supported modes:

- `COPY`
- `MOVE`
- `MOUNT`
- `REFERENCE`
- `GENERATE`
- `VIRTUALIZE`
- `IGNORE`
- `ARCHIVE`

`MOVE` is not legal during discovery; it is reserved for an approved migration phase.

## Validation vs certification

JSON Schema answers:

> Is this structurally a valid CDM object?

Operational validation answers:

> Is the company sufficiently known and governed to operate safely?

These are intentionally separate.

`specs/validation-rules.yaml` contains the v0.1 operational rules.

## Certification levels

- **CDM-0 DISCOVERED** — inventory exists.
- **CDM-1 MAPPED** — normalized records can be mapped safely.
- **CDM-2 BOOTABLE** — Company Kernel can reach core boot.
- **CDM-3 OPERABLE** — critical business processes are represented.
- **CDM-4 GOVERNED** — authority, audit, recovery, and policy gates pass.
- **CDM-5 AUTONOMY-READY** — explicit autonomy evaluation and safe AI execution gates pass.

The highest contiguous level whose required rules all pass is the computed certification level.

## Running the package validation

Python 3.11+ recommended.

```bash
python -m pip install -r requirements.txt
python scripts/validate_package.py
```

Expected v0.1 reference result:

```text
CDM v0.1 machine-contract validation
Rule/schema files: PASS
Certification tests: PASS
Sample manifest schema: PASS
Sample computed certification: CDM-4
Sample failed operational rules: VR-021
```

The example intentionally stops at CDM-4 because the ordinary sample has not completed the autonomy evaluation. The test fixture `valid-cdm5.cdm.yaml` demonstrates CDM-5.

## Implementation order

Recommended build sequence:

1. manifest/schema validator;
2. evidence store;
3. connector runtime;
4. discovery normalizer;
5. question/artifact request engine;
6. correlation and inference engine;
7. conflict/unknown resolver;
8. mapping engine;
9. operational validator;
10. certification runner;
11. CFHS materializer;
12. Company Kernel boot test.

## Versioning policy

v0.1 is intentionally strict about safety boundaries but still exploratory in domain shape.

Backward-compatible additions may appear within v0.x. Breaking field or semantic changes require a new minor specification version and migration contract.

## Important semantic rule

A complete-looking manifest is not equivalent to a complete company.

The system must never increase its readiness or certification score by converting uncertainty into invented certainty.

> An explicit unknown is more correct than an invented fact.
