# Company OS Runtime Contract v0.1

This package implements the next layer of the NCF Company OS extension:

1. **CFHS Materializer v0.1** — deterministic transformation of a validated CDM into a staged Company Filesystem Hierarchy Standard namespace.
2. **Company Kernel API v0.1** — privileged syscall/control-plane contract used by user-space applications and AI processes.

## Invariants

- AI/LLMs never run in kernel space.
- Materialization is deterministic and side-effect-free outside the selected target directory.
- Inline secrets are rejected; only opaque `secret://...` references are permitted.
- Materialization does not grant permissions. It represents already resolved CDM authority.
- Privileged external actions occur only through kernel-mediated device calls.
- Every consequential kernel call carries actor, process, trace, policy, and audit context.

## Quick validation

```bash
python materializer/tests/test_materializer.py
python kernel-api/tests_validate_contract.py
```

